HAPPY DRONES BRAND KIT
Latest version: https://happydrones.co.uk/media

WHAT'S IN HERE
  logo/svg   The logo in every version, as vector files (any size, for print and design)
  logo/png   The same, as transparent PNGs 2400 pixels wide
  mark       The drone mark on its own, plus a square profile picture (1080 x 1080)
  happy-drones-brand-guide.pdf   Four-page guide to using all of this

WHICH LOGO TO USE
  Full colour ........ on white or light backgrounds
  Reversed ........... on navy, dark or photo backgrounds
  One colour, white .. on orange or dark backgrounds
  One colour, navy ... one-colour printing on light backgrounds
  One colour, black .. only when colour isn't possible

  Leave a margin at least a quarter of the logo's height on every side.
  Full logo no smaller than 8 mm tall in print or 24 px on screen.
  Please don't stretch, tilt, recolour or add effects to it.

COLOURS
  Happy Drones Navy  #003366  RGB 0, 51, 102     CMYK 100, 50, 0, 60
  Drone Orange       #FF6B35  RGB 255, 107, 53   CMYK 0, 58, 79, 0
  Deep Orange        #D9531F  RGB 217, 83, 31    CMYK 0, 62, 86, 15  (orange text on white)
  Night Navy         #001A33  RGB 0, 26, 51      CMYK 100, 49, 0, 80
  Slate              #46617E  RGB 70, 97, 126    CMYK 44, 23, 0, 51
  Mist               #EAF1F8  RGB 234, 241, 248  CMYK 6, 3, 0, 3
  CMYK values are converted from the screen colours: ask your printer to match them on a proof.

FONTS (free from Google Fonts)
  Blinker  headings, numbers and labels   https://fonts.google.com/specimen/Blinker
  Lato     body text                      https://fonts.google.com/specimen/Lato

THE NAME
  Happy Drones: two words, capital H and D.

ABOUT HAPPY DRONES
  Happy Drones provides drone and ground photography and video across North East England.
  Run by pilot Wayne Fox, it shoots property photos, aerials and walkthrough video in a
  single visit, close-up roof inspections without ladders, and month-by-month records of
  building sites and empty buildings. CAA registered and insured for £10m.

MEDIA CONTACT
  Wayne Fox  ·  wayne@happydrones.co.uk  ·  07888 625623
